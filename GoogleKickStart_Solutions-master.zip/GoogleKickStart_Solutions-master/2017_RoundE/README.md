trapezoidCounting.py: My implementation uses two pointers. It is slower than the binary search solution proposed by official analysis. Anyways it still passes both test cases. 

copyPaste.cpp: A O(N^4) approach with optimized dp.

blackholde-small.cpp: My implementation is TLE for large dataset. I will work on this in the future. 
