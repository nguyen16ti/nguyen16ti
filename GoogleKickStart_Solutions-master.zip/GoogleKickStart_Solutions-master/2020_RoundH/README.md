rugby.cpp: the median of all values is the optimal spot, if we are trying to minimize the overall distance sum.

friends.cpp: The difficult part is to cleverly construct the graph. Running floyd-warshall afterwards is easy.
