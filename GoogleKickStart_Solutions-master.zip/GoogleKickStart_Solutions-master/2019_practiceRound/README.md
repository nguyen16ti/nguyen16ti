mural.py: the overall effect is that we can take up to at most (N+1)/2 length of subarray, and greedily it is achievable.

kickstartAlarm.cpp: Note that if you use modulus after the "+=" operator, the modulus can not take effect. e.g. A+=B%C, in this expression A is never modulus-ed by C and will grow big. 
