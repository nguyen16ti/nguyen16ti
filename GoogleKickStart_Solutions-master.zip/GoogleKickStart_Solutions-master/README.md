my AC solutions that passes ALL test cases, with explanations. <br />
EVERY problem before 2017_Round C and after 2017_round F. <br />
Some problem analysis (written by me) are the most detailed analysis on the internet (because no one writes about it :)    e.g. 2016 round e problem d) <br />
Some problem analysis provides unique approaches that I haven't seen other people use    e.g. 2020 round d problem d <br />
Some problem analysis provides my approach that is easier to implement than, and equally as good as the official solution   e.g. 2021 round f problem b <br />
