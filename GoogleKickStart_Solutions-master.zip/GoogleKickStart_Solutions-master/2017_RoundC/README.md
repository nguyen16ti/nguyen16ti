All 4 problems in this round are sort of math questions. If you are good at math, you should be able to solve them!
