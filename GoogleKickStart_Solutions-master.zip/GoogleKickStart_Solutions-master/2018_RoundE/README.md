milkTea.py: We build a trie based on the forbidden options. We also preprocess the options to find the minimum complaints we would get if we purchase optimally after each given digit. Finally we run a dfs over the trie and collect our optimal options. 

boardGame.cpp: My implementation has a theoretical time complexity as specified in the official anaysis. However, it is still not able to pass the large data set. Anyways, it is a good exercise to practice 2d segment tree and practice optimization techniques. 
