For problem 4, solution p4 will pass test cases if pypy2 is used, and robot.cpp will pass all test cases no matter what. 

global ranking 562 in this contest
